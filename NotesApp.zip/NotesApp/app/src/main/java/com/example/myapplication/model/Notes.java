package com.example.myapplication.model;

public class Notes {

    public String Notes;

    public Notes(String notes)
    {
        this.Notes = notes;
    }

    public Notes ()
    {

    }

    public String getNotes()
    {
        return Notes;
    }


    public void setNotes(String notes)
    {
        this.Notes = notes;
    }

}
