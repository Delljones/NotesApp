package com.example.myapplication;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;
import com.example.myapplication.dataPackage.DatabaseHelper;
import com.example.myapplication.model.Notes;
import java.util.ArrayList;
import java.util.List;

public class ShowAllNotes extends AppCompatActivity {
    ArrayList<String> notesArrayList;
    ArrayAdapter<String> adaptor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_notes);

        ListView notesListView = findViewById(R.id.listView);
        notesArrayList = new ArrayList<>();
        DatabaseHelper db =  new DatabaseHelper(ShowAllNotes.this);

        List<Notes> notesList = db.fetchAllNotes();

        for (Notes notes: notesList) {

            notesArrayList.add(notes.getNotes());
        }

        adaptor = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, notesArrayList);
        notesListView.setAdapter(adaptor);

    }
}