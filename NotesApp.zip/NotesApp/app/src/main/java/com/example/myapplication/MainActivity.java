package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button createNewNote = findViewById(R.id.createNewNote);
        Button showAllNotes = findViewById(R.id.showAllNotes);

        // when clicking this button then it will take you to add a note //
        createNewNote.setOnClickListener(v -> {

            Intent intent = new Intent(MainActivity.this, AddNote.class);
            startActivity(intent);});

        // when clicking this is will take you to all notes in the database that has been created

        showAllNotes.setOnClickListener(v -> {

            Intent intent2 = new Intent(MainActivity.this, ShowAllNotes.class);
            startActivity(intent2);});
    }}

