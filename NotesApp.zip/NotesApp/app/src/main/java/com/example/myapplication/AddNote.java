package com.example.myapplication;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.dataPackage.DatabaseHelper;
import com.example.myapplication.model.Notes;

public class AddNote extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_note);

        DatabaseHelper db;
        db = new DatabaseHelper(this);

        Button saveNote = findViewById(R.id.saveNote);
        EditText addNote = findViewById(R.id.addNote);

        saveNote.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String note = addNote.getText().toString();
                long result = db.insertNote(new Notes(note));

                if (result > 0)
                {
                    Toast.makeText(AddNote.this, "Note Successfully Saved",
                            Toast.LENGTH_SHORT).show();
                    // need to be able to reinstate screen //
                } else
                {
                    Toast.makeText(AddNote.this, "Not Saved", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}