package com.example.myapplication.Util;

public class Util {
    public static final int DATABASE_VERSION = 1;
    public static final String DATABASE_NAME = "note_database";
    public static final String TABLE_NAME = "notes";
    public static final String NOTE_ID = "note_id";
    public static final String NOTE = "note";
}